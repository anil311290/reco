<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PurchaseInvoiceResource;
use App\Services\PurchaseInvoiceService;
use App\Helpers\ResponseHelper;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PurchaseInvoiceApiController extends Controller
{
    protected PurchaseInvoiceService $purchaseInvoiceService;

    public function __construct(PurchaseInvoiceService $purchaseInvoiceService)
    {
        $this->purchaseInvoiceService = $purchaseInvoiceService;
    }

    /**
     * Get all purchase invoices.
     */
    public function index(Request $request): JsonResponse
    {
        $companyId = $request->user()->company_id;
        $filters = $request->only(['search', 'status', 'party_id', 'date_from', 'date_to']);

        $perPage = $request->input('per_page', 15);
        $invoices = $this->purchaseInvoiceService->getPaginated($companyId, $filters, $perPage);

        return ResponseHelper::success([
            'data' => PurchaseInvoiceResource::collection($invoices->items()),
            'current_page' => $invoices->currentPage(),
            'last_page' => $invoices->lastPage(),
            'per_page' => $invoices->perPage(),
            'total' => $invoices->total(),
        ]);
    }

    /**
     * Get invoice by ID.
     */
    public function show(int $id): JsonResponse
    {
        $invoice = $this->purchaseInvoiceService->getById($id);

        if (!$invoice || $invoice->company_id !== request()->user()->company_id) {
            return ResponseHelper::notFound('Invoice not found');
        }

        return ResponseHelper::success(new PurchaseInvoiceResource($invoice));
    }

    /**
     * Create purchase invoice.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'party_id' => 'required|exists:parties,id',
            'supplier_invoice_number' => 'nullable|string|max:100',
            'invoice_date' => 'required|date',
            'due_date' => 'required|date|after_or_equal:invoice_date',
            'notes' => 'nullable|string',
            'discount_percentage' => 'nullable|numeric|min:0|max:100',
            'lines' => 'required_without:service_lines|array|min:1',
            'lines.*.item_id' => 'nullable|exists:items,id',
            'lines.*.account_id' => 'nullable|exists:accounts,id',
            'lines.*.tax_rate_id' => 'nullable|exists:tax_rates,id',
            'lines.*.description' => 'nullable|string',
            'lines.*.quantity' => 'required_with:lines|numeric|min:0.001',
            'lines.*.unit_price' => 'required_with:lines|numeric|min:0',
            'lines.*.discount_percentage' => 'nullable|numeric|min:0|max:100',
            'service_lines' => 'required_without:lines|array|min:1',
            'service_lines.*.account_id' => 'nullable|exists:accounts,id',
            'service_lines.*.tax_rate_id' => 'nullable|exists:tax_rates,id',
            'service_lines.*.description' => 'nullable|string',
            'service_lines.*.amount' => 'required_with:service_lines|numeric|min:0',
        ]);

        $companyId = $request->user()->company_id;
        $fyId = $request->user()->company->currentFinancialYear?->id;

        $data = [
            'uuid' => \Illuminate\Support\Str::uuid(),
            'company_id' => $companyId,
            'financial_year_id' => $fyId,
            'party_id' => $validated['party_id'],
            'invoice_number' => $this->purchaseInvoiceService->generateInvoiceNumber($companyId, $fyId),
            'supplier_invoice_number' => $validated['supplier_invoice_number'] ?? null,
            'invoice_date' => $validated['invoice_date'],
            'due_date' => $validated['due_date'],
            'notes' => $validated['notes'] ?? null,
            'discount_percentage' => $validated['discount_percentage'] ?? 0,
            'status' => 'draft',
        ];

        $invoice = $this->purchaseInvoiceService->create(
            $data,
            $validated['lines'] ?? [],
            $validated['service_lines'] ?? []
        );

        $voucher = $this->purchaseInvoiceService->generateVoucher($invoice);
        if (!$voucher) {
            return ResponseHelper::error('Invoice created but accounting posting failed. Please configure required accounts.', 400);
        }

        return ResponseHelper::success(new PurchaseInvoiceResource($invoice), 'Invoice created', 201);
    }

    /**
     * Record payment against invoice.
     */
    public function payment(Request $request, int $id): JsonResponse
    {
        $invoice = $this->purchaseInvoiceService->getById($id);

        if (!$invoice || $invoice->company_id !== $request->user()->company_id) {
            return ResponseHelper::notFound('Invoice not found');
        }

        $validated = $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'payment_mode' => 'required|in:cash,bank,od',
            'cash_bank_account_id' => 'required|exists:accounts,id',
            'payment_date' => 'nullable|date',
        ]);

        try {
            $invoice = $this->purchaseInvoiceService->recordPayment($id, [
                'amount' => $validated['amount'],
                'payment_mode' => $validated['payment_mode'],
                'cash_bank_account_id' => $validated['cash_bank_account_id'],
                'payment_date' => $validated['payment_date'] ?? now()->toDateString(),
                'created_by' => $request->user()->id,
                'created_by_ip' => $request->ip(),
            ]);
        } catch (\Exception $e) {
            return ResponseHelper::error($e->getMessage());
        }

        return ResponseHelper::success(new PurchaseInvoiceResource($invoice->fresh()), 'Payment recorded and payment voucher posted');
    }

    /**
     * Update purchase invoice.
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $invoice = $this->purchaseInvoiceService->getById($id);

        if (!$invoice || $invoice->company_id !== $request->user()->company_id) {
            return ResponseHelper::notFound('Invoice not found');
        }

        $validated = $request->validate([
            'party_id' => 'required|exists:parties,id',
            'supplier_invoice_number' => 'nullable|string|max:100',
            'invoice_date' => 'required|date',
            'due_date' => 'required|date|after_or_equal:invoice_date',
            'notes' => 'nullable|string',
            'discount_percentage' => 'nullable|numeric|min:0|max:100',
            'lines' => 'required_without:service_lines|array|min:1',
            'lines.*.item_id' => 'nullable|exists:items,id',
            'lines.*.account_id' => 'nullable|exists:accounts,id',
            'lines.*.tax_rate_id' => 'nullable|exists:tax_rates,id',
            'lines.*.description' => 'nullable|string',
            'lines.*.quantity' => 'required_with:lines|numeric|min:0.001',
            'lines.*.unit_price' => 'required_with:lines|numeric|min:0',
            'lines.*.discount_percentage' => 'nullable|numeric|min:0|max:100',
            'service_lines' => 'required_without:lines|array|min:1',
            'service_lines.*.account_id' => 'nullable|exists:accounts,id',
            'service_lines.*.tax_rate_id' => 'nullable|exists:tax_rates,id',
            'service_lines.*.description' => 'nullable|string',
            'service_lines.*.amount' => 'required_with:service_lines|numeric|min:0',
        ]);

        try {
            $data = [
                'party_id' => $validated['party_id'],
                'supplier_invoice_number' => $validated['supplier_invoice_number'] ?? null,
                'invoice_date' => $validated['invoice_date'],
                'due_date' => $validated['due_date'],
                'notes' => $validated['notes'] ?? null,
                'discount_percentage' => $validated['discount_percentage'] ?? 0,
                'updated_by' => $request->user()->id,
                'updated_by_ip' => $request->ip(),
            ];

            $invoice = $this->purchaseInvoiceService->updateWithLines(
                $id,
                $data,
                $validated['lines'] ?? [],
                $validated['service_lines'] ?? []
            );

            return ResponseHelper::success(new PurchaseInvoiceResource($invoice), 'Invoice updated successfully');
        } catch (\Exception $e) {
            return ResponseHelper::error($e->getMessage());
        }
    }

    /**
     * Delete purchase invoice.
     */
    public function destroy(int $id): JsonResponse
    {
        $invoice = $this->purchaseInvoiceService->getById($id);

        if (!$invoice || $invoice->company_id !== request()->user()->company_id) {
            return ResponseHelper::notFound('Invoice not found');
        }

        try {
            $this->purchaseInvoiceService->delete($id);

            return ResponseHelper::success(null, 'Invoice deleted successfully');
        } catch (\Exception $e) {
            return ResponseHelper::error($e->getMessage());
        }
    }
}
