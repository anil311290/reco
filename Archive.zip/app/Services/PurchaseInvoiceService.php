<?php

namespace App\Services;

use App\Models\PurchaseInvoice;
use App\Models\PurchaseInvoiceLine;
use App\Models\Voucher;
use App\Models\TaxRate;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

class PurchaseInvoiceService
{
    protected VoucherService $voucherService;
    protected InvoiceAccountingService $invoiceAccountingService;
    protected PeriodLockService $periodLockService;
    protected LedgerService $ledgerService;

    public function __construct(
        VoucherService $voucherService,
        InvoiceAccountingService $invoiceAccountingService,
        PeriodLockService $periodLockService,
        LedgerService $ledgerService
    ) {
        $this->voucherService = $voucherService;
        $this->invoiceAccountingService = $invoiceAccountingService;
        $this->periodLockService = $periodLockService;
        $this->ledgerService = $ledgerService;
    }

    /**
     * Get all purchase invoices for a company.
     */
    public function getAll(int $companyId, array $filters = []): Collection
    {
        $query = PurchaseInvoice::with(['party', 'financialYear'])
            ->where('company_id', $companyId);

        if (isset($filters['status'])) {
            $query->where('status', $filters['status']);
        }
        if (isset($filters['party_id'])) {
            $query->where('party_id', $filters['party_id']);
        }
        if (isset($filters['date_from'])) {
            $query->where('invoice_date', '>=', $filters['date_from']);
        }
        if (isset($filters['date_to'])) {
            $query->where('invoice_date', '<=', $filters['date_to']);
        }
        if (isset($filters['search'])) {
            $query->where(function ($q) use ($filters) {
                $q->where('invoice_number', 'like', "%{$filters['search']}%")
                  ->orWhere('supplier_invoice_number', 'like', "%{$filters['search']}%")
                  ->orWhereHas('party', function ($pq) use ($filters) {
                      $pq->where('name', 'like', "%{$filters['search']}%");
                  });
            });
        }

        return $query->orderBy('invoice_date', 'desc')->get();
    }

    /**
     * Get paginated purchase invoices.
     */
    public function getPaginated(int $companyId, array $filters = [], int $perPage = 15): LengthAwarePaginator
    {
        $query = PurchaseInvoice::with(['party'])
            ->where('company_id', $companyId);

        if (isset($filters['status'])) {
            $query->where('status', $filters['status']);
        }
        if (isset($filters['search'])) {
            $query->where(function ($q) use ($filters) {
                $q->where('invoice_number', 'like', "%{$filters['search']}%")
                  ->orWhereHas('party', function ($pq) use ($filters) {
                      $pq->where('name', 'like', "%{$filters['search']}%");
                  });
            });
        }

        return $query->orderBy('invoice_date', 'desc')->paginate($perPage);
    }

    /**
     * Get invoice by ID with lines.
     */
    public function getById(int $id): ?PurchaseInvoice
    {
        return PurchaseInvoice::with(['party', 'financialYear', 'lines.item', 'lines.taxRate', 'lines.account'])
            ->find($id);
    }

    /**
     * Create a purchase invoice with lines.
     */
    public function create(array $data, array $lines, array $serviceLines = []): PurchaseInvoice
    {
        return DB::transaction(function () use ($data, $lines, $serviceLines) {
            $this->periodLockService->assertWritable(
                (int) $data['company_id'],
                $data['invoice_date'],
                isset($data['financial_year_id']) ? (int) $data['financial_year_id'] : null
            );

            $invoice = PurchaseInvoice::create($data);

            foreach ($lines as $index => $line) {
                $line['purchase_invoice_id'] = $invoice->id;
                $line['sort_order'] = $index;
                $line['line_type'] = 'item';

                $base = ($line['quantity'] ?? 1) * ($line['unit_price'] ?? 0);
                $discount = $base * (($line['discount_percentage'] ?? 0) / 100);
                $afterDiscount = $base - $discount;

                if (!isset($line['tax_amount']) && isset($line['tax_rate_id'])) {
                    $taxRate = TaxRate::find($line['tax_rate_id']);
                    $line['tax_amount'] = $taxRate ? $taxRate->calculateTax((float) $afterDiscount) : 0;
                }

                $line['discount_amount'] = $discount;
                $line['total'] = $afterDiscount + ($line['tax_amount'] ?? 0);
                PurchaseInvoiceLine::create($line);
            }

            // Service lines
            foreach ($serviceLines as $index => $sLine) {
                $taxRate = null;
                if (!empty($sLine['tax_rate_id'])) {
                    $taxRate = TaxRate::find($sLine['tax_rate_id']);
                }
                $amount = (float) ($sLine['amount'] ?? 0);
                $tax = $taxRate ? $taxRate->calculateTax($amount) : 0;

                PurchaseInvoiceLine::create([
                    'purchase_invoice_id' => $invoice->id,
                    'line_type'           => 'service',
                    'account_id'          => $sLine['account_id'] ?? null,
                    'tax_rate_id'         => $sLine['tax_rate_id'] ?? null,
                    'description'         => $sLine['description'] ?? null,
                    'quantity'            => 1,
                    'unit_price'          => $amount,
                    'discount_percentage' => 0,
                    'discount_amount'     => 0,
                    'tax_amount'          => $tax,
                    'total'               => $amount + $tax,
                    'sort_order'          => count($lines) + $index,
                ]);
            }

            $invoice->calculateTotals();
            return $invoice->load('lines');
        });
    }

    /**
     * Update a purchase invoice with lines.
     */
    public function updateWithLines(int $id, array $data, array $lines, array $serviceLines = []): PurchaseInvoice
    {
        return DB::transaction(function () use ($id, $data, $lines, $serviceLines) {
            $invoice = PurchaseInvoice::findOrFail($id);

            if (in_array($invoice->status, ['paid', 'partial', 'cancelled'], true)) {
                throw new \RuntimeException('Paid, partially paid, or cancelled invoices cannot be altered.');
            }

            $invoiceDate = $data['invoice_date'] ?? $invoice->invoice_date;
            $this->periodLockService->assertWritable(
                (int) $invoice->company_id,
                $invoiceDate,
                $invoice->financial_year_id ? (int) $invoice->financial_year_id : null
            );

            $invoice->update($data);

            $invoice->lines()->delete();

            foreach ($lines as $index => $line) {
                $line['purchase_invoice_id'] = $invoice->id;
                $line['sort_order'] = $index;
                $line['line_type'] = 'item';

                $base = ($line['quantity'] ?? 1) * ($line['unit_price'] ?? 0);
                $discount = $base * (($line['discount_percentage'] ?? 0) / 100);
                $afterDiscount = $base - $discount;

                if (!isset($line['tax_amount']) && isset($line['tax_rate_id'])) {
                    $taxRate = TaxRate::find($line['tax_rate_id']);
                    $line['tax_amount'] = $taxRate ? $taxRate->calculateTax((float) $afterDiscount) : 0;
                }

                $line['discount_amount'] = $discount;
                $line['total'] = $afterDiscount + ($line['tax_amount'] ?? 0);
                PurchaseInvoiceLine::create($line);
            }

            // Service lines
            foreach ($serviceLines as $index => $sLine) {
                $taxRate = null;
                if (!empty($sLine['tax_rate_id'])) {
                    $taxRate = TaxRate::find($sLine['tax_rate_id']);
                }
                $amount = (float) ($sLine['amount'] ?? 0);
                $tax = $taxRate ? $taxRate->calculateTax($amount) : 0;

                PurchaseInvoiceLine::create([
                    'purchase_invoice_id' => $invoice->id,
                    'line_type'           => 'service',
                    'account_id'          => $sLine['account_id'] ?? null,
                    'tax_rate_id'         => $sLine['tax_rate_id'] ?? null,
                    'description'         => $sLine['description'] ?? null,
                    'quantity'            => 1,
                    'unit_price'          => $amount,
                    'discount_percentage' => 0,
                    'discount_amount'     => 0,
                    'tax_amount'          => $tax,
                    'total'               => $amount + $tax,
                    'sort_order'          => count($lines) + $index,
                ]);
            }

            $invoice->calculateTotals();
            $invoice->refresh()->load(['lines.item', 'lines.taxRate', 'lines.account', 'party']);

            $postedVoucher = $invoice->vouchers()->where('status', 'posted')->first();
            if ($postedVoucher) {
                $voucherLines = $this->invoiceAccountingService->buildPurchaseVoucherLines($invoice);
                $this->voucherService->syncInvoiceVoucher(
                    $postedVoucher,
                    [
                        'party_id' => $invoice->party_id,
                        'voucher_date' => $invoice->invoice_date,
                        'narration' => "Purchase Invoice #{$invoice->invoice_number}",
                        'total' => $invoice->total,
                        'updated_by' => $invoice->updated_by,
                        'updated_by_ip' => $invoice->updated_by_ip,
                    ],
                    $voucherLines
                );
            }

            return $invoice;
        });
    }

    /**
     * Record payment against purchase invoice and post a Payment voucher (bill-wise).
     *
     * @param  array{amount:float,cash_bank_account_id:int,payment_mode:string,payment_date?:string}  $paymentData
     */
    public function recordPayment(int $invoiceId, array $paymentData): PurchaseInvoice
    {
        return DB::transaction(function () use ($invoiceId, $paymentData) {
            $invoice = PurchaseInvoice::query()
                ->whereKey($invoiceId)
                ->lockForUpdate()
                ->with(['party.account'])
                ->firstOrFail();

            if ($invoice->status === 'cancelled') {
                throw new \RuntimeException('Cancelled invoices cannot receive payments.');
            }

            if ((float) $invoice->balance_due <= 0 || $invoice->status === 'paid') {
                throw new \RuntimeException('This invoice is already fully paid.');
            }

            $hasPostedPurchaseVoucher = Voucher::query()
                ->where('purchase_invoice_id', $invoice->id)
                ->where('voucher_type', 'expense')
                ->where('status', 'posted')
                ->exists();

            if (!$hasPostedPurchaseVoucher) {
                throw new \RuntimeException('Post the purchase invoice to accounts before recording payment.');
            }

            $amount = round((float) ($paymentData['amount'] ?? 0), 2);
            if ($amount <= 0) {
                throw new \RuntimeException('Payment amount must be greater than zero.');
            }
            if ($amount > round((float) $invoice->balance_due, 2) + 0.009) {
                throw new \RuntimeException('Payment amount cannot exceed balance due.');
            }

            $paymentDate = $paymentData['payment_date'] ?? now()->toDateString();
            $settlementFy = $this->periodLockService->assertWritable(
                (int) $invoice->company_id,
                $paymentDate
            );

            $cashBankAccountId = (int) ($paymentData['cash_bank_account_id'] ?? 0);
            $paymentMode = $paymentData['payment_mode'] ?? null;
            $cashBank = \App\Models\Account::query()
                ->where('company_id', $invoice->company_id)
                ->where('id', $cashBankAccountId)
                ->where('is_active', true)
                ->first();

            if (!$cashBank || !in_array($cashBank->transaction_mode, ['cash', 'bank', 'od'], true)) {
                throw new \RuntimeException('Select a valid Cash / Bank / OD account.');
            }
            if ($paymentMode && $cashBank->transaction_mode !== $paymentMode) {
                throw new \RuntimeException('Selected account must match the payment mode.');
            }

            if ($cashBank->transaction_mode !== 'od') {
                $available = $this->ledgerService->getAvailablePaymentBalance(
                    $cashBank->id,
                    (int) $invoice->company_id,
                    (int) $settlementFy->id
                );
                if ($available !== null && $amount > $available + 0.009) {
                    throw new \RuntimeException(
                        'Insufficient balance in ' . $cashBank->account_name . '. Available: ₹' . number_format($available, 2)
                    );
                }
            }

            $partyAccountId = $invoice->party?->account_id
                ?: \App\Models\Account::query()
                    ->where('company_id', $invoice->company_id)
                    ->where('account_code', \App\Models\Account::CODE_AP)
                    ->value('id');
            if (!$partyAccountId) {
                throw new \RuntimeException('Accounts Payable control account is missing.');
            }

            $this->voucherService->create([
                'uuid' => (string) \Illuminate\Support\Str::uuid(),
                'company_id' => $invoice->company_id,
                'financial_year_id' => $settlementFy->id,
                'party_id' => $invoice->party_id,
                'voucher_type' => 'payment',
                'voucher_date' => $paymentDate,
                'narration' => "Payment against Purchase Invoice #{$invoice->invoice_number}",
                'purchase_invoice_id' => $invoice->id,
                'created_by' => $paymentData['created_by'] ?? auth()->id(),
                'created_by_ip' => $paymentData['created_by_ip'] ?? request()->ip(),
                'lines' => [
                    [
                        'account_id' => (int) $partyAccountId,
                        'party_id' => $invoice->party_id,
                        'debit' => $amount,
                        'credit' => 0,
                        'description' => "Payment against Invoice #{$invoice->invoice_number}",
                    ],
                    [
                        'account_id' => $cashBank->id,
                        'debit' => 0,
                        'credit' => $amount,
                        'description' => "Paid for Invoice #{$invoice->invoice_number}",
                    ],
                ],
            ]);

            $invoice->recordPayment($amount);

            return $invoice->fresh(['party', 'financialYear', 'lines.item', 'lines.taxRate', 'lines.account']);
        });
    }

    /**
     * Delete a purchase invoice.
     */
    public function delete(int $id): bool
    {
        $invoice = PurchaseInvoice::findOrFail($id);
        if ($invoice->vouchers()->exists() || in_array($invoice->status, ['verified', 'paid', 'partial', 'cancelled'], true)) {
            throw new \RuntimeException(
                'A posted purchase invoice cannot be deleted because accounting entries exist. Cancel/reverse it instead.'
            );
        }
        return $invoice->delete();
    }

    /**
     * Get overdue invoices.
     */
    public function getOverdue(int $companyId): Collection
    {
        return PurchaseInvoice::where('company_id', $companyId)->overdue()->get();
    }

    /**
     * Generate next invoice number (company-wide sequence; not reset per FY).
     */
    public function generateInvoiceNumber(int $companyId, int $financialYearId): string
    {
        $lastInvoice = PurchaseInvoice::where('company_id', $companyId)
            ->where('invoice_number', 'like', 'PUR-%')
            ->orderBy('invoice_number', 'desc')
            ->first();

        $nextNumber = $lastInvoice
            ? intval(substr($lastInvoice->invoice_number, -6)) + 1
            : 1;

        return 'PUR-' . str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Generate voucher from purchase invoice via VoucherService.
     */
    public function generateVoucher(PurchaseInvoice $invoice, ?int $accountId = null): ?Voucher
    {
        return DB::transaction(function () use ($invoice, $accountId) {
            $existing = Voucher::query()
                ->where('purchase_invoice_id', $invoice->id)
                ->where('voucher_type', 'expense')
                ->where('status', 'posted')
                ->first();

            if ($existing) {
                return $existing->load(['party', 'lines.account']);
            }

            $lines = $this->invoiceAccountingService->buildPurchaseVoucherLines($invoice, $accountId);

            $voucher = $this->voucherService->createFromPurchaseInvoice([
                'company_id' => $invoice->company_id,
                'financial_year_id' => $invoice->financial_year_id,
                'party_id' => $invoice->party_id,
                'voucher_date' => $invoice->invoice_date,
                'narration' => "Purchase Invoice #{$invoice->invoice_number}",
                'total' => $invoice->total,
                'purchase_invoice_id' => $invoice->id,
                'created_by' => $invoice->created_by,
            ], $lines);

            $invoice->update(['status' => 'verified']);

            return $voucher;
        });
    }
}
