<?php $__env->startSection('title', 'FAQ - Reco'); ?>
<?php $__env->startSection('description', 'Find answers to frequently asked questions about Reco accounting software, subscriptions, and features.'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<section class="page-header bg-light">
    <div class="container text-center py-3">
        <h1 class="fw-bold mb-2"><?php echo e($page->title ?? 'Frequently Asked Questions'); ?></h1>
        <p class="text-muted mb-0"><?php echo e($page->meta_description ?? 'Find answers to common questions about our accounting software'); ?></p>
    </div>
</section>

<!-- FAQ Accordion -->
<section class="py-5 section-padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if(count($faqs) > 0): ?>
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category && $category !== 'General'): ?>
                    <h5 class="fw-semibold text-primary mb-3 mt-4"><?php echo e($category); ?></h5>
                    <?php endif; ?>
                    <div class="accordion mb-4" id="faqAccordion<?php echo e(Str::slug($category ?? 'general')); ?>">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item border-0 mb-2 shadow-sm rounded-3 overflow-hidden">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed fw-semibold" type="button" 
                                        data-bs-toggle="collapse" 
                                        data-bs-target="#faq<?php echo e($faq['id'] ?? $index); ?>">
                                    <?php echo e($faq['question']); ?>

                                </button>
                            </h2>
                            <div id="faq<?php echo e($faq['id'] ?? $index); ?>" class="accordion-collapse collapse" 
                                 data-bs-parent="#faqAccordion<?php echo e(Str::slug($category ?? 'general')); ?>">
                                <div class="accordion-body text-muted small">
                                    <?php echo nl2br(e($faq['answer'])); ?>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-question-circle fs-1 text-muted"></i>
                    <p class="text-muted mt-3">FAQs are being prepared. Check back soon!</p>
                </div>
                <?php endif; ?>

                <!-- Still have questions -->
                <div class="text-center mt-5 pt-4 border-top">
                    <h5 class="fw-semibold">Still have questions?</h5>
                    <p class="text-muted">Can't find the answer you're looking for? Contact our support team.</p>
                    <a href="<?php echo e(route('website.contact')); ?>" class="btn btn-primary">
                        <i class="bi bi-chat-dots me-2"></i>Contact Us
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Projects/offline-first/resources/views/website/faq.blade.php ENDPATH**/ ?>