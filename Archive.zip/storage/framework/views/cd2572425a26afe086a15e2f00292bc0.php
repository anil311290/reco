<?php
    $voucherLabels = [
        'income' => 'Sales',
        'expense' => 'Purchase',
        'payment' => 'Payment',
        'receipt' => 'Receipt',
        'journal' => 'Adjustment',
    ];
    $voucherLabel = $voucherLabels[$voucher->voucher_type] ?? ucfirst($voucher->voucher_type);
?>

<?php $__env->startSection('title', $voucherLabel . ' Voucher'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-6">
        <h4 class="mb-0"><?php echo e($voucherLabel); ?> Voucher</h4>
        <small class="text-muted"><?php echo e($voucher->voucher_number); ?></small>
    </div>
    <div class="col-md-6 text-md-end">
        <a href="<?php echo e(route('admin.vouchers.type', $voucher->voucher_type)); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left me-2"></i>Back to Vouchers
        </a>
        <?php if($voucher->status === 'draft'): ?>
        <a href="<?php echo e(route('admin.vouchers.edit', $voucher->id)); ?>" class="btn btn-primary ms-2">
            <i class="bi bi-pencil me-2"></i>Edit Voucher
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title mb-3">Voucher Details</h5>
                <div class="mb-3">
                    <div class="text-muted small">Voucher Number</div>
                    <div><?php echo e($voucher->voucher_number); ?></div>
                </div>
                <div class="mb-3">
                    <div class="text-muted small">Type</div>
                    <div><?php echo e($voucherLabel); ?></div>
                </div>
                <div class="mb-3">
                    <div class="text-muted small">Date</div>
                    <div><?php echo e(optional($voucher->voucher_date)->format('d/m/Y')); ?></div>
                </div>
                <div class="mb-3">
                    <div class="text-muted small">Status</div>
                    <div><span class="badge <?php echo e($voucher->status_badge_class); ?>"><?php echo e(ucfirst($voucher->status)); ?></span></div>
                </div>
                <div class="mb-3">
                    <div class="text-muted small">Party</div>
                    <div><?php echo e($voucher->party?->name ?? '-'); ?></div>
                </div>
                <div class="mb-0">
                    <div class="text-muted small">Narration</div>
                    <div><?php echo e($voucher->narration ?: '-'); ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title mb-3">Voucher Lines</h5>
                <div class="table-responsive">
                    <table class="table table-bordered align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Account</th>
                                <th class="text-end">Debit</th>
                                <th class="text-end">Credit</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $voucher->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($line->account?->account_name ?? '-'); ?></td>
                                <td class="text-end"><?php echo e(number_format((float) $line->debit, 2)); ?></td>
                                <td class="text-end"><?php echo e(number_format((float) $line->credit, 2)); ?></td>
                                <td><?php echo e($line->description ?: '-'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th class="text-end">Totals</th>
                                <th class="text-end"><?php echo e(number_format((float) $voucher->total_debit, 2)); ?></th>
                                <th class="text-end"><?php echo e(number_format((float) $voucher->total_credit, 2)); ?></th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Projects/offline-first/resources/views/admin/vouchers/show.blade.php ENDPATH**/ ?>