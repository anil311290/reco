<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receivables Outstanding</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; color: #333; font-size: 12px; }
        .container { padding: 20px; }
        .header { text-align: center; margin-bottom: 20px; }
        .table { width: 100%; border-collapse: collapse; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; }
        .table th { background: #f7f7f7; text-align: left; }
        .text-right { text-align: right; }
        tfoot td { font-weight: bold; background: #f3f3f3; }
    </style>
</head>
<body>
<div class="container">
    <div class="header"><h1>Receivables Outstanding</h1></div>
    <table class="table">
        <thead>
        <tr>
            <th>#</th>
            <th>Party</th>
            <th>Mobile</th>
            <th>Email</th>
            <th class="text-right">Balance (₹) Dr</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $report['debtors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($item['party']->name); ?></td>
                <td><?php echo e($item['party']->mobile ?? '-'); ?></td>
                <td><?php echo e($item['party']->email ?? '-'); ?></td>
                <td class="text-right"><?php echo e(number_format($item['balance'], 2)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5">No outstanding receivables</td></tr>
        <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4">Total Outstanding</td>
                <td class="text-right">₹<?php echo e(number_format($report['total'], 2)); ?></td>
            </tr>
        </tfoot>
    </table>
</div>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Projects/offline-first/resources/views/exports/debtors-outstanding.blade.php ENDPATH**/ ?>