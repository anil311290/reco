<?php $__env->startSection('title', 'Payables Outstanding'); ?>

<?php echo $__env->make('admin.reports._theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="reports-shell">
    <div class="report-hero">
        <div class="row g-4 align-items-center">
            <div class="col-lg-8">
                <span class="report-eyebrow"><i class="bi bi-people-fill"></i> Party Outstanding</span>
                <h1 class="report-title">Payables Outstanding</h1>
                <p class="report-subtitle">Creditors with credit balances on their linked ledgers (Accounts Payable).</p>
            </div>
            <div class="col-lg-4">
                <div class="report-toolbar">
                    <a href="<?php echo e(route('admin.reports.index')); ?>" class="btn report-btn-soft"><i class="bi bi-arrow-left me-1"></i>Back to Reports</a>
                    <a href="<?php echo e(route('admin.export.excel', ['type' => 'creditors'])); ?>" class="btn btn-outline-success report-btn-export">
                        <i class="bi bi-file-earmark-spreadsheet"></i>Excel
                    </a>
                    <a href="<?php echo e(route('admin.export.creditors-outstanding.pdf')); ?>" class="btn btn-outline-danger report-btn-export">
                        <i class="bi bi-file-earmark-pdf"></i>PDF
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="report-stats-grid">
        <div class="report-stat report-stat--warning">
            <p class="report-stat-label">Total Outstanding</p>
            <h3 class="report-stat-value">₹<?php echo e(number_format($report['total'], 2)); ?></h3>
            <p class="report-stat-note">Open payables across all creditors.</p>
        </div>
        <div class="report-stat report-stat--info">
            <p class="report-stat-label">Creditors Count</p>
            <h3 class="report-stat-value"><?php echo e(count($report['creditors'])); ?></h3>
            <p class="report-stat-note">Suppliers with outstanding balances.</p>
        </div>
    </div>

    <div class="report-panel">
        <div class="report-panel-header">
            <h6 class="report-panel-title"><i class="bi bi-person-lines-fill text-warning"></i>Outstanding Creditors</h6>
            <span class="report-pill report-pill--warning">₹<?php echo e(number_format($report['total'], 2)); ?></span>
        </div>
        <div class="report-panel-body report-panel-body--flush">
            <table class="table report-table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Party</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th class="text-end">Balance (₹) Cr</th>
                        <th class="text-center">History</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $report['creditors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td class="fw-semibold">
                            <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'parties.view')): ?>
                                <a href="<?php echo e(route('admin.parties.show', $item['party']->id)); ?>" class="report-detail-link" title="View party history">
                                    <?php echo e($item['party']->name); ?>

                                </a>
                            <?php else: ?>
                                <?php echo e($item['party']->name); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item['party']->mobile ?? '-'); ?></td>
                        <td><?php echo e($item['party']->email ?? '-'); ?></td>
                        <td class="text-end fw-bold text-warning">₹<?php echo e(number_format($item['balance'], 2)); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e(route('admin.parties.show', $item['party']->id)); ?>" class="btn btn-sm btn-outline-primary" title="View party history">History</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="text-muted text-center py-4">No outstanding payables</td></tr>
                    <?php endif; ?>
                </tbody>
                <?php if(count($report['creditors']) > 0): ?>
                <tfoot>
                    <tr>
                        <td colspan="4">Total Outstanding</td>
                        <td class="text-end fw-bold">₹<?php echo e(number_format($report['total'], 2)); ?></td>
                        <td></td>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Projects/offline-first/resources/views/admin/reports/creditors-outstanding.blade.php ENDPATH**/ ?>