<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales Invoice <?php echo e($invoice->invoice_number); ?></title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            color: #222;
            margin: 0;
            padding: 0;
            font-size: 11px;
            line-height: 1.4;
        }
        .container {
            padding: 24px;
        }
        .header-table,
        .info-table,
        .items-table,
        .totals-table {
            width: 100%;
            border-collapse: collapse;
        }
        .header-table td {
            vertical-align: top;
            padding: 0;
        }
        .company-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 4px;
        }
        .invoice-title {
            font-size: 22px;
            font-weight: bold;
            text-align: right;
            color: #1a365d;
        }
        .invoice-number {
            text-align: right;
            font-size: 13px;
            color: #555;
            margin-top: 4px;
        }
        .section-title {
            font-size: 11px;
            font-weight: bold;
            color: #666;
            text-transform: uppercase;
            margin-bottom: 4px;
        }
        .info-box {
            border: 1px solid #d9d9d9;
            padding: 10px;
            margin-top: 16px;
            min-height: 90px;
        }
        .info-table {
            margin-top: 16px;
        }
        .info-table td {
            width: 50%;
            vertical-align: top;
            padding-right: 12px;
        }
        .meta-row {
            margin-bottom: 3px;
        }
        .meta-label {
            color: #666;
            display: inline-block;
            width: 90px;
        }
        .items-table {
            margin-top: 18px;
        }
        .items-table th,
        .items-table td {
            border: 1px solid #ccc;
            padding: 7px 6px;
        }
        .items-table th {
            background: #f3f4f6;
            font-size: 10px;
            text-transform: uppercase;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .totals-wrap {
            margin-top: 12px;
        }
        .totals-table {
            width: 280px;
            margin-left: auto;
        }
        .totals-table td {
            padding: 5px 0;
        }
        .totals-table .grand-total td {
            border-top: 2px solid #222;
            font-size: 14px;
            font-weight: bold;
            padding-top: 8px;
        }
        .notes {
            margin-top: 18px;
            padding: 10px;
            border: 1px solid #e5e5e5;
            background: #fafafa;
        }
        .footer {
            margin-top: 24px;
            padding-top: 10px;
            border-top: 1px solid #ddd;
            font-size: 9px;
            color: #777;
            text-align: center;
        }
        .status-badge {
            display: inline-block;
            padding: 2px 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            font-size: 10px;
            text-transform: uppercase;
        }
    </style>
</head>
<body>
    <div class="container">
        <table class="header-table">
            <tr>
                <td>
                    <div class="company-name"><?php echo e($invoice->company->name ?? 'Company'); ?></div>
                    <?php if($invoice->company?->address): ?>
                        <div><?php echo e($invoice->company->address); ?></div>
                    <?php endif; ?>
                    <?php if($invoice->company?->city || $invoice->company?->state): ?>
                        <div><?php echo e(trim(($invoice->company->city ?? '') . ', ' . ($invoice->company->state ?? ''), ', ')); ?></div>
                    <?php endif; ?>
                    <?php if($invoice->company?->phone): ?>
                        <div>Phone: <?php echo e($invoice->company->phone); ?></div>
                    <?php endif; ?>
                    <?php if($invoice->company?->email): ?>
                        <div>Email: <?php echo e($invoice->company->email); ?></div>
                    <?php endif; ?>
                    <?php if($invoice->company?->gst_number): ?>
                        <div><strong>GSTIN:</strong> <?php echo e($invoice->company->gst_number); ?></div>
                    <?php endif; ?>
                    <?php if($invoice->company?->pan_number): ?>
                        <div><strong>PAN:</strong> <?php echo e($invoice->company->pan_number); ?></div>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="invoice-title">TAX INVOICE</div>
                    <div class="invoice-number"><?php echo e($invoice->invoice_number); ?></div>
                </td>
            </tr>
        </table>

        <table class="info-table">
            <tr>
                <td>
                    <div class="info-box">
                        <div class="section-title">Bill To</div>
                        <strong><?php echo e($invoice->party->name ?? 'N/A'); ?></strong><br>
                        <?php if($invoice->party?->address): ?>
                            <?php echo e($invoice->party->address); ?><br>
                        <?php endif; ?>
                        <?php if($invoice->party?->city || $invoice->party?->state): ?>
                            <?php echo e(trim(($invoice->party->city ?? '') . ', ' . ($invoice->party->state ?? ''), ', ')); ?><br>
                        <?php endif; ?>
                        <?php if($invoice->party?->mobile): ?>
                            Phone: <?php echo e($invoice->party->mobile); ?><br>
                        <?php endif; ?>
                        <?php if($invoice->party?->gstin): ?>
                            <strong>GSTIN:</strong> <?php echo e($invoice->party->gstin); ?>

                        <?php endif; ?>
                    </div>
                </td>
                <td>
                    <div class="info-box">
                        <div class="section-title">Invoice Details</div>
                        <div class="meta-row">
                            <span class="meta-label">Invoice #</span>
                            <strong><?php echo e($invoice->invoice_number); ?></strong>
                        </div>
                        <div class="meta-row">
                            <span class="meta-label">Date</span>
                            <?php echo e($invoice->invoice_date?->format('d M Y') ?? '-'); ?>

                        </div>
                        <div class="meta-row">
                            <span class="meta-label">Due Date</span>
                            <?php echo e($invoice->due_date?->format('d M Y') ?? '-'); ?>

                        </div>
                        <?php if($invoice->reference_number): ?>
                        <div class="meta-row">
                            <span class="meta-label">Reference</span>
                            <?php echo e($invoice->reference_number); ?>

                        </div>
                        <?php endif; ?>
                        <div class="meta-row">
                            <span class="meta-label">Status</span>
                            <span class="status-badge"><?php echo e(ucfirst($invoice->status)); ?></span>
                        </div>
                        <?php if($invoice->financialYear): ?>
                        <div class="meta-row">
                            <span class="meta-label">FY</span>
                            <?php echo e($invoice->financialYear->name); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        </table>

        <table class="items-table">
            <thead>
                <tr>
                    <th style="width: 4%;">#</th>
                    <th style="width: 34%;">Description</th>
                    <th class="text-right" style="width: 10%;">Qty</th>
                    <th class="text-right" style="width: 14%;">Unit Price</th>
                    <th class="text-right" style="width: 10%;">Disc %</th>
                    <th class="text-right" style="width: 14%;">Tax</th>
                    <th class="text-right" style="width: 14%;">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $invoice->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td>
                        <?php echo e($line->item->name ?? $line->account->account_name ?? $line->description ?? '-'); ?>

                        <?php if($line->description && ($line->item || $line->account)): ?>
                            <br><span style="color:#666;"><?php echo e($line->description); ?></span>
                        <?php endif; ?>
                        <?php if($line->taxRate): ?>
                            <br><span style="color:#666; font-size:9px;"><?php echo e($line->taxRate->tax_name); ?> (<?php echo e(number_format($line->taxRate->tax_rate, 2)); ?>%)</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-right"><?php echo e(number_format($line->quantity, 2)); ?></td>
                    <td class="text-right"><?php echo e(number_format($line->unit_price, 2)); ?></td>
                    <td class="text-right"><?php echo e(number_format($line->discount_percentage, 2)); ?></td>
                    <td class="text-right"><?php echo e(number_format($line->tax_amount, 2)); ?></td>
                    <td class="text-right"><?php echo e(number_format($line->total, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="totals-wrap">
            <table class="totals-table">
                <tr>
                    <td>Subtotal</td>
                    <td class="text-right"><?php echo e(number_format($invoice->subtotal, 2)); ?></td>
                </tr>
                <?php if($invoice->discount_amount > 0): ?>
                <tr>
                    <td>Discount</td>
                    <td class="text-right">-<?php echo e(number_format($invoice->discount_amount, 2)); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <td>Tax</td>
                    <td class="text-right"><?php echo e(number_format($invoice->tax_amount, 2)); ?></td>
                </tr>
                <tr class="grand-total">
                    <td>Total (<?php echo e($invoice->currency ?? 'INR'); ?>)</td>
                    <td class="text-right"><?php echo e(number_format($invoice->total, 2)); ?></td>
                </tr>
                <?php if($invoice->amount_paid > 0): ?>
                <tr>
                    <td>Paid</td>
                    <td class="text-right"><?php echo e(number_format($invoice->amount_paid, 2)); ?></td>
                </tr>
                <?php endif; ?>
                <?php if($invoice->balance_due > 0): ?>
                <tr>
                    <td><strong>Balance Due</strong></td>
                    <td class="text-right"><strong><?php echo e(number_format($invoice->balance_due, 2)); ?></strong></td>
                </tr>
                <?php endif; ?>
            </table>
        </div>

        <?php if($invoice->notes): ?>
        <div class="notes">
            <strong>Notes:</strong> <?php echo e($invoice->notes); ?>

        </div>
        <?php endif; ?>

        <div class="footer">
            Generated on <?php echo e(now()->format('d M Y, h:i A')); ?>

        </div>
    </div>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Projects/offline-first/resources/views/exports/sales-invoice.blade.php ENDPATH**/ ?>