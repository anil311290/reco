<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Day Book Report</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; color: #333; margin: 0; padding: 0; font-size: 12px; }
        .container { padding: 20px; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h1 { margin: 0; font-size: 22px; }
        .table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; }
        .table th { background: #f7f7f7; text-align: left; }
        .text-right { text-align: right; }
        tfoot td { font-weight: bold; background: #f3f3f3; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Day Book</h1>
        <p>Date: <?php echo \App\Helpers\DateHelper::formatDate($date); ?></p>
    </div>

    <table class="table">
        <thead>
        <tr>
            <th>Voucher #</th>
            <th>Type</th>
            <th>Particulars</th>
            <th>Narration</th>
            <th class="text-right">Debit (₹)</th>
            <th class="text-right">Credit (₹)</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $report['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($row['voucher_number']); ?></td>
                <td><?php echo e(ucfirst($row['voucher_type'])); ?></td>
                <td><?php echo e($row['account_name']); ?></td>
                <td><?php echo e($row['narration'] ?? '-'); ?></td>
                <td class="text-right"><?php echo e($row['debit'] > 0 ? number_format($row['debit'], 2) : '-'); ?></td>
                <td class="text-right"><?php echo e($row['credit'] > 0 ? number_format($row['credit'], 2) : '-'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6">No entries found for selected date</td></tr>
        <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4">Total</td>
                <td class="text-right">₹<?php echo e(number_format($report['total_debit'], 2)); ?></td>
                <td class="text-right">₹<?php echo e(number_format($report['total_credit'], 2)); ?></td>
            </tr>
        </tfoot>
    </table>
</div>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Projects/offline-first/resources/views/exports/day-book.blade.php ENDPATH**/ ?>